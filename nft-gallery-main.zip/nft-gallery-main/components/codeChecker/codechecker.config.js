export default {
  iframeId: 'sketch-iframe',
  sketchFile: 'sketch.js',
  maxAllowedLoadTime: 3000, // in ms
  varaitionsOptions: [1, 3, 5, 10, 15, 20],
}
