export const GRID_DEFAULT_WIDTH = {
  small: 16 * 15,
  medium: 16 * 20,
  large: 16 * 25,
}
