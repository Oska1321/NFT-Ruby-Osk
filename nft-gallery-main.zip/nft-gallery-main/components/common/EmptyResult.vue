<template>
  <section class="px-6 py-12 text-center">
    <div class="title is-4">
      {{ $t('general.searchNoResultsTitle') }}
    </div>
    <div class="subtitle is-6">
      {{ $t('general.searchNoResultsText') }}
    </div>
  </section>
</template>
