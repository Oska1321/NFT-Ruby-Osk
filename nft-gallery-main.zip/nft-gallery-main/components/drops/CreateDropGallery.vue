<template>
  <div class="svg-icons relative">
    <img src="/drops/create_drop1.svg" class="svg-one absolute" />
    <img src="/drops/create_drop2.svg" class="svg-two absolute z-10" />
    <img src="/drops/BlueShade.svg" class="ellipse absolute" />
    <img src="/drops/create_drop3.svg" class="svg-three absolute" />
    <img src="/drops/PinkShade.svg" class="vector absolute" />
    <img src="/drops/create_drop4.svg" class="svg-four absolute" />
  </div>
</template>

<style scoped lang="scss">
.svg-icons {
  width: 154px;
  height: 141px;
}
.svg-one {
  top: 34px;
  left: 52px;
}
.svg-two {
  top: 68.6171875px;
  left: 32px;
}
.svg-three {
  top: 20.24px;
  left: 45px;
}
.svg-four {
  top: 19px;
  left: 98.431640625px;
}
.vector {
  top: 20px;
  left: 50.43px;
}
</style>
