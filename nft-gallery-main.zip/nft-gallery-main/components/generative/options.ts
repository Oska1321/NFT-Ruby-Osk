export const gender = ['waifu', 'boy', 'geisha']

// export const

export const fingersCrossed = [
  '4k',
  '8k',
  'high-quality',
  'trending on artstation',
  'award winning',
]

export const vibes = [
  'vaporwave',
  'post-apocalyptic',
  'gothic',
  'fantasy',
  'sci-fi',
  'steampunk',
  'memphis',
  'dieselpunk',
  'afrofuturism',
  'cyberpunk',
  'manga',
]

export const art = ['photo', 'painting']

export const lights = [
  'ambient',
  'awaking nature',
  'bounce',
  'cinematic',
  'colorful',
  'glow',
  'low-key',
  'natural',
  'nostalgic',
  'pink neon',
  'practical',
  'ring',
  'soft',
  'studio',
  'sun rays',
  'sunrise',
  'sunset',
]

export const framing = [
  'close-up',
  'front-view',
  'full-body',
  'medium-shot',
  'portrait',
  'side-view',
  'wide-shot',
]

export const clothes = [
  'crop top',
  'flower dress',
  'flower t-shirt',
  'light dress',
  'rainbow shirt',
  'school uniform',
  'shirt and shorts',
  'sportswear',
  'summer shirt',
  'swimsuit',
  'tank top',
]

export const accessories = [
  'bunny ears',
  'butterfly wings',
  'flower bouquet',
  'flower hat',
  'fox ears',
  'fox tail',
  'icecream in hand',
  'kitsune ears',
  'ladybug wings',
  'rabbit ears',
  'strawhat',
  'sunglasses',
  'tanuki ears',
  'tulips in hand',
  'umbrella over head',
]

export const filmTypes = [
  'autochrome',
  'color',
  'color-splash',
  'lomography',
  'monochrome',
  'polaroid',
]

export const styles = [
  'abstract',
  'acrylic',
  'ballpoint pen',
  'chalk',
  'charcoal',
  'digital',
  'fantasy',
  'high-quality',
  'low-poly',
  'oil',
  'pastel',
  'pencil sketch',
  'photorealistic',
  'pixel art',
  'pop art',
  'realistic',
  'ukiyo-e',
  'watercolor',
]

export const inspiredBy = [
  'Pixar',
  'Disney',
  'Dreamworks',
  'Comics',
  'Ghibli',
  'The Simpsons',
]

export const inspirations = [
  'Akira Toriyama',
  'Eiichiro Oda',
  'Hayao Miyazaki',
  'Hideaki Anno',
  'Hiroshi Yoshida',
  'Ivan Shishkin',
  'Katsuhiro Otomo',
  'Kentaro Miura',
  'Kuniyoshi',
  'Makoto Shinkai',
  'Masashi Kishimoto',
  'Satoshi Kon',
  'Toshi Yoshida',
  'Yoji Shinkawa',
]

export const guidance = ['5', '7', '10', '12']
