<template>
  <div>
    <!-- step 1 phase -->
    <MigrateStepsSignLoader1 />

    <!-- step 2 phase -->
    <MigrateStepsSignLoader2 />

    <!-- step 3 phase -->
    <MigrateStepsSignLoader3 />
  </div>
</template>

<style lang="scss">
.v-border {
  @apply bg-toggle-active-switch;
  width: 1px;
  margin-left: 20px;
  margin-right: 41px;
}
</style>
