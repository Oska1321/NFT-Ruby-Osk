export enum ModalCloseType {
  BACK = 'back',
  NAVIGATION = 'navigation',
}
