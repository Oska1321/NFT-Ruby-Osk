<template>
  <NeoField>
    <Auth />
  </NeoField>
</template>

<script lang="ts" setup>
import { NeoField } from '@kodadot1/brick'
</script>
